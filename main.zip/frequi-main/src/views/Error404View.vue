<template>
  <div>
    <h1 class="mb-5">404 Error.</h1>
    <p class="h4">Ahhhhhhhh! The page you are looking for does not exist.</p>
    <p>
      Don't worry, you can head back to
      <RouterLink to="/"> <span>the main page</span> </RouterLink>.
    </p>
  </div>
</template>
