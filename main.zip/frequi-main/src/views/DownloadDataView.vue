<script setup lang="ts"></script>

<template>
  <DownloadDataMain class="pt-4" />
</template>
