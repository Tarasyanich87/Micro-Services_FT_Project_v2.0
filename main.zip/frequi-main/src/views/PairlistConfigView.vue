<script setup lang="ts"></script>

<template>
  <PairlistConfigurator class="pt-4" />
</template>
