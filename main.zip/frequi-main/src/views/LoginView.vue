<script setup lang="ts"></script>

<template>
  <div class="border max-w-xl mx-auto p-4">
    <DraggableContainer header="Freqtrade bot Login">
      <BotLogin ref="loginForm" />
    </DraggableContainer>
  </div>
</template>
