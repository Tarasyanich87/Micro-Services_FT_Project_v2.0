<script setup lang="ts"></script>

<template>
  <div class="p-1 md:p-4 md:pe-2 h-full">
    <LogViewer />
  </div>
</template>
