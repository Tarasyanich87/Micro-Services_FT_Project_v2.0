export { default as deepMerge } from 'deepmerge';
