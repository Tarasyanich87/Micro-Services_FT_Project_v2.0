<template>
  <main class="dark:bg-[#010101]">
    <RouterView />
  </main>
</template>
