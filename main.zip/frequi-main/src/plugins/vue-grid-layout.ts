import VueDraggableGrid from '@noction/vue-draggable-grid';
import '@noction/vue-draggable-grid/styles';

export { VueDraggableGrid };
